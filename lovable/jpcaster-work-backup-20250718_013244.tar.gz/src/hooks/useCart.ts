import { useState, useEffect, useCallback } from 'react'
import { toast } from '@/hooks/use-toast'

interface CartItem {
  id: string
  name: string
  price: number
  image: string
  quantity: number
  slug: string
}

interface CartState {
  items: CartItem[]
  loading: boolean
  itemsCount: number
  totalAmount: number
}

export function useCart() {
  const [cartState, setCartState] = useState<CartState>({
    items: [],
    loading: true,
    itemsCount: 0,
    totalAmount: 0
  })

  // Load cart from localStorage (에러 핸들링 강화)
  const loadCart = useCallback(() => {
    try {
      // localStorage 접근 가능 여부 확인
      if (typeof Storage === 'undefined') {
        console.warn('⚠️ localStorage가 지원되지 않는 브라우저입니다.');
        return [];
      }
      
      const savedCart = localStorage.getItem('shopping_cart')
      if (!savedCart) {
        console.log('🛒 새로운 장바구니를 시작합니다.');
        return [];
      }
      
      const parsedCart = JSON.parse(savedCart);
      console.log('🛒 장바구니 로드 성공:', parsedCart.length, '개 아이템');
      return parsedCart;
    } catch (error) {
      console.error('❌ 장바구니 로드 실패:', error);
      // localStorage 초기화 시도
      try {
        localStorage.removeItem('shopping_cart');
        console.log('🔧 손상된 장바구니 데이터를 정리했습니다.');
      } catch (e) {
        console.error('❌ localStorage 정리 실패:', e);
      }
      return []
    }
  }, [])

  // Save cart to localStorage (에러 핸들링 강화)
  const saveCart = useCallback((items: CartItem[]) => {
    try {
      if (typeof Storage === 'undefined') {
        console.warn('⚠️ localStorage가 지원되지 않아 장바구니를 저장할 수 없습니다.');
        return;
      }
      
      localStorage.setItem('shopping_cart', JSON.stringify(items))
      console.log('💾 장바구니 저장 성공:', items.length, '개 아이템');
    } catch (error) {
      console.error('❌ 장바구니 저장 실패:', error);
      // 사용자에게 알림
      if (error.name === 'QuotaExceededError') {
        console.warn('⚠️ 브라우저 저장소가 가득참. 일부 데이터를 삭제해주세요.');
      }
    }
  }, [])

  // Initialize cart (useWishlist 패턴 적용)
  useEffect(() => {
    const items = loadCart()
    const itemsCount = items.reduce((sum: number, item: CartItem) => sum + item.quantity, 0)
    const totalAmount = items.reduce((sum: number, item: CartItem) => sum + item.price * item.quantity, 0)
    
    setCartState({
      items,
      loading: false,
      itemsCount,
      totalAmount
    })
  }, [loadCart])

  // Add item to cart (함수형 업데이트 패턴 사용)
  const addItem = useCallback((item: Omit<CartItem, 'quantity'> & { quantity?: number }) => {
    console.log('🛒 useCart.addItem 함수 시작:', item.name, '수량:', item.quantity || 1)
    console.log('📋 현재 장바구니 상태:', cartState)
    
    setCartState(prevState => {
      console.log('🔄 이전 상태:', prevState)
      const currentItems = prevState.items
      const existingItem = currentItems.find(i => i.id === item.id)
      
      let updatedItems: CartItem[]
      if (existingItem) {
        console.log('🔄 기존 상품 수량 증가:', existingItem.name, existingItem.quantity, '->', existingItem.quantity + (item.quantity || 1))
        updatedItems = currentItems.map(i => 
          i.id === item.id 
            ? { ...i, quantity: i.quantity + (item.quantity || 1) }
            : i
        )
      } else {
        console.log('➕ 새로운 상품 추가:', item.name)
        updatedItems = [...currentItems, { ...item, quantity: item.quantity || 1 }]
      }
      
      const itemsCount = updatedItems.reduce((sum, item) => sum + item.quantity, 0)
      const totalAmount = updatedItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
      
      console.log('💾 장바구니 저장 시도:', updatedItems.length, '개 아이템, 총', itemsCount, '개')
      
      // localStorage 저장
      saveCart(updatedItems)
      
      const newState = {
        items: updatedItems,
        loading: false,
        itemsCount,
        totalAmount
      }
      
      console.log('✅ 새로운 상태 반환:', newState)
      console.log('🔢 itemsCount 값:', itemsCount) // 추가 디버깅
      
      // 상태가 즉시 반영되도록 강제 리렌더링 트리거
      setTimeout(() => {
        console.log('⏰ 지연된 상태 확인 - itemsCount:', newState.itemsCount)
      }, 100)
      
      return newState
    })
    
    toast({
      title: "장바구니에 추가됨",
      description: "상품이 장바구니에 추가되었습니다."
    })
  }, [saveCart])

  // Remove item (함수형 업데이트 패턴 사용)
  const removeItem = useCallback((itemId: string) => {
    setCartState(prevState => {
      const updatedItems = prevState.items.filter(item => item.id !== itemId)
      const itemsCount = updatedItems.reduce((sum, item) => sum + item.quantity, 0)
      const totalAmount = updatedItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
      
      // localStorage 저장
      saveCart(updatedItems)
      
      return {
        items: updatedItems,
        loading: false,
        itemsCount,
        totalAmount
      }
    })
    
    toast({
      title: "상품 제거됨",
      description: "장바구니에서 상품이 제거되었습니다."
    })
  }, [saveCart])

  // Update item quantity (함수형 업데이트 패턴 사용)
  const updateQuantity = useCallback((itemId: string, quantity: number) => {
    if (quantity <= 0) {
      return removeItem(itemId)
    }
  
    setCartState(prevState => {
      const updatedItems = prevState.items.map(item => 
        item.id === itemId ? { ...item, quantity } : item
      )
      
      const itemsCount = updatedItems.reduce((sum, item) => sum + item.quantity, 0)
      const totalAmount = updatedItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
      
      // localStorage 저장
      saveCart(updatedItems)
      
      return {
        items: updatedItems,
        loading: false,
        itemsCount,
        totalAmount
      }
    })
    }, [saveCart, removeItem])

  // Clear cart
  const clearCart = useCallback(() => {
    setCartState({
      items: [],
      loading: false,
      itemsCount: 0,
      totalAmount: 0
    })
    
    saveCart([])
  }, [saveCart])

  // Legacy function for backward compatibility
  const addToCart = useCallback(async (productId: string, quantity: number = 1) => {
    console.warn('addToCart with productId is deprecated, use addItem instead')
  }, [])

  return {
    ...cartState,
    addItem,
    addToCart,
    updateQuantity,
    removeItem,
    clearCart
  }
}