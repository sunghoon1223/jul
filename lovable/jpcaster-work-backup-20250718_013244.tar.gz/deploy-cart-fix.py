#!/usr/bin/env python3
import os
import ftplib
import tarfile
from pathlib import Path

# FTP 설정
ftp_host = 'ftp.studio-sb.com'
ftp_user = 'studio-sb.com'
ftp_password = 'JP93541**'
remote_dir = 'public_html'

print('🚀 Starting FTP deployment for cart fixes...')

try:
    # 압축된 dist 파일 생성
    tar_path = 'jpcaster-dist-cart-fix.tar.gz'
    with tarfile.open(tar_path, 'w:gz') as tar:
        tar.add('dist', arcname='.')
    print(f'📦 Created compressed file: {tar_path}')
    
    # FTP 연결
    ftp = ftplib.FTP(ftp_host)
    ftp.login(ftp_user, ftp_password)
    ftp.cwd(remote_dir)
    print('✅ Connected to FTP server')
    
    # dist 폴더 내용 업로드
    dist_path = Path('dist')
    
    def upload_directory(local_path, remote_path=''):
        for item in local_path.iterdir():
            if item.is_file():
                remote_file = f"{remote_path}/{item.name}" if remote_path else item.name
                print(f"📤 Uploading {item.name}...")
                with open(item, 'rb') as f:
                    ftp.storbinary(f'STOR {remote_file}', f)
            elif item.is_dir():
                remote_dir_name = f"{remote_path}/{item.name}" if remote_path else item.name
                try:
                    ftp.mkd(remote_dir_name)
                except ftplib.error_perm:
                    pass  # Directory might already exist
                upload_directory(item, remote_dir_name)
    
    upload_directory(dist_path)
    
    ftp.quit()
    print('🎉 Cart fix deployment completed successfully!')
    
except Exception as e:
    print(f'❌ Deployment failed: {e}')